package edu.kit.informatik.baker.player;

import edu.kit.informatik.baker.Game;

public class Purse {

    private int goldAmount;

    Purse() {
        this.goldAmount = Game.START_GOLD_AMOUNT;
    }

    public boolean canAfford(int price) {
        return this.goldAmount >= price;
    }

    public int getGoldAmount() {
        return this.goldAmount;
    }

    public void addGold(int amount) {
        this.goldAmount += amount;
    }

    public boolean deductGold(int amount) {
        if (this.canAfford(amount)) {
            this.goldAmount -= amount;
            return true;
        }
        return false;
    }

    public boolean won() {
        return this.canAfford(Game.WIN_GOLD_AMOUNT);
    }
}
