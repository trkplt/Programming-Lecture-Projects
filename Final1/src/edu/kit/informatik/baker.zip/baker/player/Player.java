package edu.kit.informatik.baker.player;

import edu.kit.informatik.baker.Game;
import edu.kit.informatik.baker.board.Field;
import edu.kit.informatik.baker.board.StartField;
import edu.kit.informatik.baker.product.Dish;
import edu.kit.informatik.baker.product.DishComparator;
import edu.kit.informatik.baker.product.RawMaterial;
import edu.kit.informatik.baker.ui.Main;

import java.util.Set;
import java.util.TreeSet;

public class Player {

    public static final int PLAYER_START_NUMBER = 1;
    public static final int MIN_PLAYER_NUMBER = 2;
    public static final int MAX_PLAYER_NUMBER = 4;
    private static final String PLAYER_NAME_START = "P";

    private final String name;
    private final Pack pack;
    private final Purse purse;
    private final Set<Dish> prepared;
    private boolean novice;

    public Player(int index) {
        this.name = PLAYER_NAME_START + index;
        this.pack = new Pack();
        this.purse = new Purse();
        this.prepared = new TreeSet<>(new DishComparator());
        this.novice = true;
    }

    public static String getPlayerPattern() {
        String pattern = Main.PATTERN_GROUP_INIT;

        for (int i = PLAYER_START_NUMBER; i < MAX_PLAYER_NUMBER; i++) {
            pattern += PLAYER_NAME_START + i + Main.PATTERN_OR;
        }

        return pattern.substring(Main.OUT_STRING_START_INDEX, pattern.length() - Main.OUT_STRING_END_OFFSET)
                + Main.PATTERN_GROUP_END; //TODO: substring kullanma
    }

    public String getName() {
        return this.name;
    }

    public int getGold() {
        return this.purse.getGoldAmount();
    }

    private boolean canPrepareDish(Dish dish) {
        for (RawMaterial rawMaterial : RawMaterial.values()) {
            if (dish.getReqRawMaterial(rawMaterial) > this.pack.getRawMaterialAmount(rawMaterial)) {
                return false;
            }
        }
        return true;
    }

    //TODO: CANPREPARE RETURN TYPE SET INSTEAD OF STRING
    public TreeSet<Dish> canPrepare() {
        TreeSet<Dish> possible = new TreeSet<>(new DishComparator());

        for (Dish dish : Dish.values()) {
            if (canPrepareDish(dish)) {
                possible.add(dish);
            }
        }
        return possible;
    }

    public boolean prepare(Dish dish) {
        if (!canPrepareDish(dish)) {
            return false;
        }

        for (RawMaterial rawMaterial : RawMaterial.values()) {
            this.pack.deductRawMaterial(rawMaterial, dish.getReqRawMaterial(rawMaterial));
        }

        this.purse.addGold(dish.getProfit());
        this.prepared.add(dish);

        if (novice && prepared.size() == Dish.values().length) {
            this.purse.addGold(Game.MASTER_PRIZE);
            this.novice = false;
        }
        return true;
    }

    public void harvest() {
        this.purse.addGold(Game.HARVEST_GOLD_EARN);
    }

    public void move(Field field) {
        if (field instanceof StartField) {
            this.purse.addGold(Game.START_FIELD_PRIZE);
        }
    }

    public boolean canBuy(int price) {
        return this.purse.canAfford(price);
    }

    public void buy(RawMaterial rawMaterial, int price) {
        this.pack.addRawMaterial(rawMaterial);
        this.purse.deductGold(price);
    }

    public boolean won() {
        return this.purse.won();
    }

    @Override
    public String toString() {
        int gold = this.purse.getGoldAmount();
        int flour = this.pack.getRawMaterialAmount(RawMaterial.FLOUR);
        int egg = this.pack.getRawMaterialAmount(RawMaterial.EGG);
        int milk = this.pack.getRawMaterialAmount(RawMaterial.MILK);
        return gold + Main.SEPARATOR + flour + Main.SEPARATOR
                + egg + Main.SEPARATOR + milk;
    }
}
