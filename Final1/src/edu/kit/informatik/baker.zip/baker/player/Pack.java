package edu.kit.informatik.baker.player;

import edu.kit.informatik.baker.product.RawMaterial;

import java.util.HashMap;

public class Pack {

    private static final int START_AMOUNT_PER_MATERIAL = 0;

    private final HashMap<RawMaterial, Integer> bag;

    Pack() {
        this.bag = new HashMap<>();

        for (RawMaterial rawMaterial : RawMaterial.values()) {
            bag.put(rawMaterial, START_AMOUNT_PER_MATERIAL);
        }
    }

    public int getRawMaterialAmount(RawMaterial rawMaterial) {
        return bag.get(rawMaterial);
    }

    public void addRawMaterial(RawMaterial rawMaterial) {
        bag.replace(rawMaterial, bag.get(rawMaterial) + 1);
    }

    public boolean deductRawMaterial(RawMaterial rawMaterial, int amount) {
        if (this.getRawMaterialAmount(rawMaterial) < amount) {
            return false;
        }
        bag.replace(rawMaterial, bag.get(rawMaterial) - amount);
        return true;
    }
}
