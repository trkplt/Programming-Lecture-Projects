package edu.kit.informatik.baker.board;

import edu.kit.informatik.baker.product.RawMaterial;

public abstract class Field {

    public static final int ABBREVIATION_LENGTH = 1;

    private final int index;
    private final String abbreviation;
    private final RawMaterial rawMaterial;

    protected Field(int index, String abbreviation, RawMaterial rawMaterial) {
        this.index = index;
        this.abbreviation = abbreviation;
        this.rawMaterial = rawMaterial;
    }

    protected int getIndex() {
        return this.index;
    }

    public RawMaterial getRawMaterial() {
        return this.rawMaterial;
    }

    public String getAbbreviation() {
        return this.abbreviation;
    }

    public static Field createField(int index, String abbreviation) {
        Field field;
        switch (abbreviation) {
            case "S":
                field = new StartField(index);
                break;
            case "M":
                field = new Mill(index);
                break;
            case "C":
                field = new CowPasture(index);
                break;
            case "H":
                field = new HenHouse(index);
                break;
            default:
                field = null;
                break;
        }
        return field;
    }
}
