package edu.kit.informatik.baker.board;

import edu.kit.informatik.baker.product.RawMaterial;

public class CowPasture extends Field {

    private static final RawMaterial RAW_MATERIAL = RawMaterial.MILK;
    private static final String ABBREVIATION = "C";

    public CowPasture(int index) {
        super(index, ABBREVIATION, RAW_MATERIAL);
    }
}
