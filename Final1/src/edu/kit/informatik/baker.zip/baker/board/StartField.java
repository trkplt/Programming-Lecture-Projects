package edu.kit.informatik.baker.board;

import edu.kit.informatik.baker.product.RawMaterial;

public class StartField extends Field {

    private static final RawMaterial RAW_MATERIAL = null;
    private static final String ABBREVIATION = "S";

    public StartField(int index) {
        super(index, ABBREVIATION, RAW_MATERIAL);
    }
}
