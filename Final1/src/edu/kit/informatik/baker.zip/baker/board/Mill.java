package edu.kit.informatik.baker.board;

import edu.kit.informatik.baker.product.RawMaterial;

public class Mill extends Field {

    private static final RawMaterial RAW_MATERIAL = RawMaterial.FLOUR;
    private static final String ABBREVIATION = "M";

    public Mill(int index) {
        super(index, ABBREVIATION, RAW_MATERIAL);
    }
}
