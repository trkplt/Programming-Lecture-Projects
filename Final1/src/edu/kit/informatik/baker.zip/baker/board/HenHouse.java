package edu.kit.informatik.baker.board;

import edu.kit.informatik.baker.product.RawMaterial;

public class HenHouse extends Field {

    private static final RawMaterial RAW_MATERIAL = RawMaterial.EGG;
    private static final String ABBREVIATION = "H";

    public HenHouse(int index) {
        super(index, ABBREVIATION, RAW_MATERIAL);
    }
}
