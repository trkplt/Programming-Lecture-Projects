package edu.kit.informatik.baker.board;

import edu.kit.informatik.baker.Game;
import edu.kit.informatik.baker.ui.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Board {

    private static final String MILL_ABBREVIATION = "M";
    private static final String COW_PASTURE_ABBREVIATION = "C";
    private static final String HEN_HOUSE_ABBREVIATION = "H";
    private static final String FIELDS_PATTERN = "(" + MILL_ABBREVIATION + Main.PATTERN_OR + COW_PASTURE_ABBREVIATION
            + Main.PATTERN_OR + HEN_HOUSE_ABBREVIATION + ")";
    private static final String BOARD_PATTERN = "S;(" + FIELDS_PATTERN + ";){0,23}(" + FIELDS_PATTERN + ")";
    private static final int SAME_FIELD_MAX_MARGIN = 4;

    private final List<Field> fields;
    private final boolean boardValid;

    public Board(String fieldString) {
        Pattern pattern = Pattern.compile(BOARD_PATTERN);
        Matcher matcher = pattern.matcher(fieldString);

        if (!matcher.matches()) {
            this.fields = null;
            this.boardValid = false;
            return;
        }

        this.fields = new ArrayList<>();
        int fieldIndex = 0;

        for (int i = Main.OUT_STRING_START_INDEX; i < fieldString.length(); i++) {
            String representation = fieldString.substring(i, i + Main.OUT_STRING_END_OFFSET);
            if (representation.equals(";")) {
                continue;
            }

            Field field = Field.createField(fieldIndex, representation);
            this.fields.add(field);
            ++fieldIndex;
        }

        /*this.fields = new ArrayList<>();
        this.fields.add(new StartField(Game.START_FIELD_INDEX));

        for (int i = Main.COMMAND_FIRST_GROUP; i <= matcher.groupCount(); i++) {
            String representation = matcher.group(i);

            if (representation.length() != Field.ABBREVIATION_LENGTH) {
                representation = representation.substring(Main.OUT_STRING_START_INDEX,
                        representation.length() - Main.OUT_STRING_END_OFFSET);
            }

            Field field = Field.createField(i, representation);
            this.fields.add(field);
        }*/

        /*String fieldsInTheMiddle = matcher.group(Main.COMMAND_FIRST_GROUP);
        Pattern middlePattern = Pattern.compile("(M|C|H)");
        Matcher matcherInTheMiddle = middlePattern.matcher(fieldsInTheMiddle);

        if (!matcherInTheMiddle.matches()) {
            this.boardValid = false;
            return;
        }

        int index;
        for (index = Main.COMMAND_FIRST_GROUP; index <= matcherInTheMiddle.groupCount(); index++) {
            Field field = Field.createField(index, matcherInTheMiddle.group(index));
            this.fields.add(field);
        }

        Field lastField = Field.createField(index, matcher.group(matcher.groupCount()));
        this.fields.add(lastField);*/

        this.boardValid = minFieldNumRuleFollowed() && nextFieldRuleFollowed() && fourFieldsRuleFollowed();
    }

    private boolean minFieldNumRuleFollowed() {
        boolean millFound = false;
        boolean cowPastureFound = false;
        boolean henHouseFound = false;

        for (Field field : this.fields) {
            switch (field.getAbbreviation()) {
                case MILL_ABBREVIATION:
                    millFound = true;
                    break;
                case COW_PASTURE_ABBREVIATION:
                    cowPastureFound = true;
                    break;
                case HEN_HOUSE_ABBREVIATION:
                    henHouseFound = true;
                    break;
                default:
                    break;
            }
        }

        return millFound && cowPastureFound && henHouseFound;
    }

    private boolean nextFieldRuleFollowed() {
        String prevFieldAbbreviation = Main.EMPTY_STRING;

        for (Field field : this.fields) {
            String currentFieldAbbreviation = field.getAbbreviation();

            if (currentFieldAbbreviation.equals(prevFieldAbbreviation)) {
                return false;
            }

            prevFieldAbbreviation = currentFieldAbbreviation;
        }

        String secondFieldAbbreviation = fields.get(Game.START_FIELD_INDEX + 1).getAbbreviation();
        return !secondFieldAbbreviation.equals(prevFieldAbbreviation);
    }

    private boolean fourFieldsRuleCounter(List<Integer> fieldIndexList) {
        int prevIndex = Game.START_FIELD_INDEX;

        for (Integer currentIndex : fieldIndexList) {
            if (currentIndex - prevIndex > SAME_FIELD_MAX_MARGIN) {
                return false;
            }
            prevIndex = currentIndex;
        }

        return fields.size() - prevIndex + fieldIndexList.get(Game.START_FIELD_INDEX) <= SAME_FIELD_MAX_MARGIN;
    }

    private boolean fourFieldsRuleFollowed() {
        List<Integer> millIndexes = new ArrayList<>();
        List<Integer> cowPastureIndexes = new ArrayList<>();
        List<Integer> henHouseIndexes = new ArrayList<>();

        for (Field field : this.fields) {
            switch (field.getAbbreviation()) {
                case MILL_ABBREVIATION:
                    millIndexes.add(field.getIndex());
                    break;
                case COW_PASTURE_ABBREVIATION:
                    cowPastureIndexes.add(field.getIndex());
                    break;
                case HEN_HOUSE_ABBREVIATION:
                    henHouseIndexes.add(field.getIndex());
                    break;
                default:
                    break;
            }
        }

        return fourFieldsRuleCounter(millIndexes)
                && fourFieldsRuleCounter(cowPastureIndexes)
                && fourFieldsRuleCounter(henHouseIndexes);
    }

    public Field getStartField() {
        return this.fields.get(Game.START_FIELD_INDEX);
    }

    public boolean isBoardValid() {
        return this.boardValid;
    }

    public Field getNextField(Field field, int moves) {
        int index = field.getIndex() + moves;

        if (index < fields.size()) {
            return fields.get(index);
        } else {
            return getNextField(fields.get(Game.START_FIELD_INDEX), index - fields.size());
        }
    }
}
