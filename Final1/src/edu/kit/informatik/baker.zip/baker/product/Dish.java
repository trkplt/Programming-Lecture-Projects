package edu.kit.informatik.baker.product;

import java.util.HashMap;

public enum Dish {

    YOGHURT("yoghurt", 0, 0, 3, 8),
    MERINGUE("meringue", 0, 3, 0, 9),
    BREAD("bread", 3, 0, 0, 10),
    BUN("bun", 2, 0, 1, 11),
    CREPE("crepe", 1, 2, 0, 12),
    PUDDING("pudding", 0, 1, 2, 13),
    CAKE("cake", 2, 2, 2, 22);

    private final String name;
    private final HashMap<RawMaterial, Integer> reqRawMaterials;
    private final int profit;

    Dish(String name, int flour, int egg, int milk, int profit) {
        this.name = name;
        this.reqRawMaterials = new HashMap<>();
        this.profit = profit;

        this.reqRawMaterials.put(RawMaterial.FLOUR, flour);
        this.reqRawMaterials.put(RawMaterial.EGG, egg);
        this.reqRawMaterials.put(RawMaterial.MILK, milk);
    }

    public String getName() {
        return this.name;
    }

    public int getReqRawMaterial(RawMaterial rawMaterial) {
        return reqRawMaterials.get(rawMaterial);
    }

    public int getProfit() {
        return this.profit;
    }

    public static String getPattern() {
        String pattern = "("; //TODO:

        for (Dish dish : Dish.values()) {
            pattern += dish.name + "|";//TODO:
        }

        pattern = pattern.substring(0, pattern.length() - 1);
        pattern += ")";//TODO:
        return pattern;
    }

    public static Dish getDish(String input) {
        for (Dish dish : Dish.values()) {
            if (input.equals(dish.name)) {
                return dish;
            }
        }
        return null;
    }
}
