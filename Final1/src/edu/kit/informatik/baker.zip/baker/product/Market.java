package edu.kit.informatik.baker.product;

import edu.kit.informatik.baker.Game;
import edu.kit.informatik.baker.ui.Main;

import java.util.Arrays;
import java.util.HashMap;
import java.util.TreeSet;

public class Market {

    private final HashMap<RawMaterial, Integer> stock;

    public Market() {
        this.stock = new HashMap<>();

        for (RawMaterial rawMaterial : RawMaterial.values()) {
            this.stock.put(rawMaterial, Game.MARKET_START_STOCKS);
        }
    }

    public int getPrice(RawMaterial rawMaterial) {
        int amount = this.stock.get(rawMaterial);
        if (--amount >= 0) {
            return Game.MARKET_SIZE_PER_MATERIAL - amount;
        }
        return -1;
    }

    public int getAmount(RawMaterial rawMaterial) {
        return this.stock.get(rawMaterial);
    }

    public boolean canTakeRawMaterial(RawMaterial rawMaterial) {
        return stock.get(rawMaterial) < Game.MARKET_SIZE_PER_MATERIAL;
    }

    public boolean canGiveRawMaterial(RawMaterial rawMaterial) {
        return stock.get(rawMaterial) > 0;
    }

    public boolean addRawMaterial(RawMaterial rawMaterial) {
        if (this.canTakeRawMaterial(rawMaterial)) {
            stock.replace(rawMaterial, stock.get(rawMaterial) + 1);
            return true;
        }
        return false;
    }

    public boolean deductRawMaterial(RawMaterial rawMaterial) {
        if (this.canGiveRawMaterial(rawMaterial)) {
            stock.replace(rawMaterial, stock.get(rawMaterial) - 1);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        String out = Main.EMPTY_STRING;
        TreeSet<RawMaterial> rawMaterials = new TreeSet<>(new RawMaterialComparator(this));
        rawMaterials.addAll(Arrays.asList(RawMaterial.values()));

        for (RawMaterial rawMaterial : rawMaterials) {
            out += this.stock.get(rawMaterial) + Main.SEPARATOR + rawMaterial.getName()
                    + System.lineSeparator();
        }

        //TODO: StringJoiner
        out = out.substring(Main.OUT_STRING_START_INDEX, out.length() - Main.OUT_STRING_END_OFFSET);
        return out;
    }
}
