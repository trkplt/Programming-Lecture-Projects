package edu.kit.informatik.baker.product;

import edu.kit.informatik.baker.ui.Main;

public enum RawMaterial {
    FLOUR("flour"),
    EGG("egg"),
    MILK("milk");

    private final String name;

    RawMaterial(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public static String getPattern() {
        String pattern = "("; //TODO: Change

        for (RawMaterial rawMaterial : RawMaterial.values()) {
            pattern += rawMaterial.name + Main.PATTERN_OR;
        }

        pattern = pattern.substring(0, pattern.length() - 1);
        pattern += ")"; //TODO :
        return pattern;
    }

    public static RawMaterial getRawMaterial(String input) {
        for (RawMaterial rawMaterial : RawMaterial.values()) {
            if (input.equals(rawMaterial.name)) {
                return rawMaterial;
            }
        }
        return null;
    }
}
