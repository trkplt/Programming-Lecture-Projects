package edu.kit.informatik.baker.product;

import java.util.Comparator;

public class RawMaterialComparator implements Comparator<RawMaterial> {

    private static final int GREATER = 1;
    private static final int LESSER = -1;
    private static final int NEUTRAL = 0;

    private final Market market;

    public RawMaterialComparator(final Market market) {
        this.market = market;
    }

    //TODO: String compareTo?
    private int compareLexicographically(RawMaterial first, RawMaterial second) {
        String firstName = first.getName().toLowerCase();
        String secondName = second.getName().toLowerCase();
        int firstLength = firstName.length();
        int secondLength = secondName.length();
        int out = NEUTRAL;

        for (int i = 0; i < Math.min(firstLength, secondLength); i++) {
            int firstChar = firstName.charAt(i);
            int secondChar = secondName.charAt(i);

            if (firstChar < secondChar) {
                out = LESSER;
                break;
            } else if (firstChar > secondChar) {
                out = GREATER;
                break;
            }
        }

        if (out == NEUTRAL && firstLength < secondLength) {
            out = LESSER;
        } else if (out == NEUTRAL && firstLength > secondLength) {
            out = GREATER;
        }
        return out;
    }

    @Override
    public int compare(RawMaterial first, RawMaterial second) {
        int firstAmount = this.market.getAmount(first);
        int secondAmount = this.market.getAmount(second);
        int out;

        if (first == second) {
            out = NEUTRAL;
        } else if (firstAmount < secondAmount) {
            out = LESSER;
        } else if (firstAmount > secondAmount) {
            out = GREATER;
        } else {
            out = this.compareLexicographically(first, second);
        }
        return out;
    }
}
