package edu.kit.informatik.baker.ui;

public enum ProgramState {
    RUNNING,
    CLOSED;
}
