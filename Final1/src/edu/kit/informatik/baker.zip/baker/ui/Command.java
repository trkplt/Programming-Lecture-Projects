package edu.kit.informatik.baker.ui;

import edu.kit.informatik.baker.Game;
import edu.kit.informatik.baker.player.Player;
import edu.kit.informatik.baker.product.Dish;
import edu.kit.informatik.baker.product.RawMaterial;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Command {

    ROLL("roll" + Main.SPACE + Game.ROLL_PATTERN) {
        @Override
        public String process(Matcher input, Game game) {
            if (game.isActivePlayerMoved()) {
                return PLAYER_MOVED;
            }

            int rollNumber = Integer.parseInt(input.group(Main.COMMAND_FIRST_GROUP));
            game.moveActivePlayer(rollNumber);

            String winOut = Command.winMessage(game);
            String normalOut = game.getActiveFieldAbbreviation() + Main.SEPARATOR + game.getActivePlayerGold();
            return winOut == null ? normalOut : winOut;
        }
    },
    HARVEST("harvest") {
        @Override
        public String process(Matcher input, Game game) {
            if (game.isGameFinished()) {
                return GAME_FINISHED;
            } else if (game.isActivePlayerBought()) {
                return PLAYER_BOUGHT;
            } else if (game.isActivePlayerHarvested()) {
                return PLAYER_HARVESTED;
            } else if (!game.isActivePlayerMoved()) {
                return PLAYER_NOT_MOVED;
            } else if (game.isActiveFieldStart()) {
                return START_FIELD_ERROR;
            }

            String rawMaterial = null;
            if (game.isCapacityEnough()) {
                rawMaterial = game.harvestActivePlayer();
            } else {
                return MARKET_FULL;
            }

            String winOut = Command.winMessage(game);
            String normalOut = rawMaterial + Main.SEPARATOR + game.getActivePlayerGold();
            return winOut == null ? normalOut : winOut;
        }
    },
    BUY("buy" + Main.SPACE + RawMaterial.getPattern()) {
        @Override
        public String process(Matcher input, Game game) {

            //TODO: STARTFIELDDA BUY OLMUYOR
            if (game.isGameFinished()) {
                return GAME_FINISHED;
            } else if (game.isActivePlayerHarvested()) {
                return PLAYER_HARVESTED;
            } else if (!game.isActivePlayerMoved()) {
                return PLAYER_NOT_MOVED;
            }

            String nameOfRawMaterial = input.group(Main.COMMAND_FIRST_GROUP);
            boolean canBuy = game.canActivePlayerBuy(nameOfRawMaterial);
            boolean stockEnough = game.isStockEnough(nameOfRawMaterial);

            if (!stockEnough) {
                return MARKET_EMPTY;
            } else if (!canBuy) {
                return NOT_ENOUGH_GOLD;
            } else {
                int price = game.buy(nameOfRawMaterial);
                return price + Main.SEPARATOR + game.getActivePlayerGold();
            }
        }
    },
    PREPARE("prepare" + Main.SPACE + Dish.getPattern()) {
        @Override
        public String process(Matcher input, Game game) {
            if (game.isGameFinished()) {
                return GAME_FINISHED;
            } else if (!game.isActivePlayerMoved()) {
                return Command.PLAYER_NOT_MOVED;
            }

            String dishName = input.group(Main.COMMAND_FIRST_GROUP);
            boolean successful = game.prepare(dishName);
            int gold = game.getActivePlayerGold();

            String winOut = Command.winMessage(game);
            String normalOut = successful ? String.valueOf(gold) : NOT_ENOUGH_MATERIALS;
            return winOut == null ? normalOut : winOut;
        }
    },
    CAN_PREPARE("can-prepare\\?") { //TODO:
        @Override
        public String process(Matcher input, Game game) {
            if (game.isGameFinished()) {
                return GAME_FINISHED;
            }
            return game.getDoableDishes();
        }
    },
    SHOW_MARKET("show-market") {
        @Override
        public String process(Matcher input, Game game) {
            return game.getMarketSummary();
        }
    },
    SHOW_PLAYER("show-player" + Main.SPACE + Player.getPlayerPattern()) {
        @Override
        public String process(Matcher input, Game game) {
            String out = game.getPlayerSummary(input.group(Main.COMMAND_FIRST_GROUP));
            return out == null ? NO_SUCH_PLAYER : out;
        }
    },
    TURN("turn") {
        @Override
        public String process(Matcher input, Game game) {
            if (game.isGameFinished()) {
                return GAME_FINISHED;
            } else if (!game.isActivePlayerMoved()) {
                return PLAYER_NOT_MOVED;
            }

            return game.turn();
        }
    },
    QUIT("quit") {
        @Override
        public String process(Matcher input, Game game) {
            game.quit();
            return null;
        }
    };

    private static final String COMMAND_NOT_FOUND = Main.ERROR_START + "command not found!";
    private static final String EXECUTE_FAIL = "this command cannot be executed!";
    private static final String PLAYER_MOVED = Main.ERROR_START + "active player already rolled the dice in this turn!";
    private static final String GAME_FINISHED = Main.ERROR_START + "one of the players won, " + EXECUTE_FAIL;
    private static final String PLAYER_BOUGHT = Main.ERROR_START + "active player already bought something, "
            + EXECUTE_FAIL;
    private static final String PLAYER_HARVESTED = Main.ERROR_START + "active player already harvested, "
            + EXECUTE_FAIL;
    private static final String PLAYER_NOT_MOVED = Main.ERROR_START + "active player not moved yet, " + EXECUTE_FAIL;
    private static final String START_FIELD_ERROR = Main.ERROR_START + "the active player landed on start field, "
            + EXECUTE_FAIL;
    private static final String MARKET_FULL = Main.ERROR_START + "the market cannot buy the harvested raw material!";
    private static final String MARKET_EMPTY = Main.ERROR_START + "the market does not have enough stock of the "
            + "specified raw material!";
    private static final String NOT_ENOUGH_GOLD = Main.ERROR_START + "active player does not have enough gold!";
    private static final String NOT_ENOUGH_MATERIALS = Main.ERROR_START + "active player does not have enough "
            + "raw materials!";
    private static final String NO_SUCH_PLAYER = Main.ERROR_START + "there is no such player!";

    private final Pattern pattern;

    Command(final String pattern) {
        this.pattern = Pattern.compile(pattern);
    }

    public static String processCommand(String input, Game game) {
        for (final Command command : Command.values()) {
            final Matcher matcher = command.pattern.matcher(input);

            if (matcher.matches()) {
                return command.process(matcher, game);
            }
        }
        return COMMAND_NOT_FOUND;
    }

    public static String winMessage(Game game) {
        if (game.isGameFinished()) {
            return game.getActivePlayerName() + " wins";
        }
        return null;
    }

    public abstract String process(Matcher input, Game game);
}
